package comp1721.cwk2;

import java.util.ArrayList;
import java.util.List;

/**
 * A class to represent a 5 card hand.
 *
 * <p>Stores 5 Card objects which are
 * all drawn from the Deck.</p>
 *
 * @author Saul Cooperman
 */

public class PokerHand extends CardCollection{
    static int FULL_SIZE = 5;
    /**
     * Constructor for empty poker hand.
     */
    public PokerHand(){
        super();
    }
    /**
     * Constructor for defined hand.
     *
     * @param hand the hand in the form RANKSUIT with spaces
     */
    public PokerHand(String hand){
        super();
        String[] parts = hand.split(" ");
        for (String part : parts) {
            add(new Card(part));
        }
    }
    /**
     * Counts frequency of each rank in hand.
     *
     * @return integer array with frequency stored in index of array
     */
    public int[] repetitions(){
        int[] cardsCount = new int[13];
        for(Card card: cards){
            cardsCount[card.getRank().ordinal()]++;
        }
        return cardsCount;
    }
    /**
     * Determines if hand is two pair.
     *
     * <p>This is 2 pairs of 2 different ranks.</p>
     *
     * @return if the hand is a two pair, true/false
     */
    public boolean isTwoPairs(){
        int counter=0;
        if(size()!=FULL_SIZE){
            return false;
        }
        int[] count = repetitions();
        for(int i = 0; i < 13; i++){
            if(count[i]==2){
                counter++;
            }
        }
        if(isThreeOfAKind()){
            return false;
        }
        return counter==2;
    }
    /**
     * Determines if hand is a three of a kind.
     *
     * <p>This is 3 of one rank.</p>
     *
     * @return if the hand is a three of a kind, true/false
     */
    public boolean isThreeOfAKind(){
        boolean flag=false;
        if(size()!=FULL_SIZE){
            return false;
        }
        int[] count = repetitions();

        for(int i = 0; i < 13; i++){
            if(count[i]==3){
                flag=true;
            }
            if(count[i]==2) {
                flag = false;
                break;
            }
        }
        return flag;
    }
    /**
     * Determines if hand is a four of a kind.
     *
     * <p>This is 4 of one rank.</p>
     *
     * @return if the hand is a four of a kind, true/false
     */
    public boolean isFourOfAKind(){
        boolean flag=false;
        if(size()!=FULL_SIZE){
            return false;
        }
        int[] count = repetitions();
        for(int i = 0; i < 13; i++){
            if(count[i]==4){
                flag=true;
                break;
            }
        }
        return flag;
    }
    /**
     * Determines if hand is a full house.
     *
     * <p>This is 3 of one rank and 2 of another.</p>
     *
     * @return if the hand is a full house, true/false
     */
    public boolean isFullHouse(){
        if(size()!=FULL_SIZE){
            return false;
        }
        int counter=0;
        int[] count = repetitions();
        for(int i = 0; i < 13; i++){
            if(count[i]==2 || count[i]==3){
                counter+=count[i];
            }
        }
        return counter==5;
    }
    /**
     * Determines if hand is a flush.
     *
     * <p>This is all the same suit.</p>
     *
     * @return if the hand is a flush, true/false
     */
    public boolean isFlush(){
        if(size()!=FULL_SIZE){
            return false;
        }
        if(isStraight()){
            return false;
        }
        for(Card c1: cards){
            int counter=0;
            for(Card c2: cards){
                if(c1.getSuit()==c2.getSuit()){
                    counter++;
                }
            }
            if(counter==5){
                return true;
            }
        }
        return false;
    }
    /**
     * Determines if hand is a straight.
     *
     * <p>This is 5 consecutive ranks. This includes
     * TJQKA as a high-ace straight</p>
     *
     * @return if the hand is a straight, true/false
     */
    public boolean isStraight(){
        if(size()!=FULL_SIZE){
            return false;
        }
        int[] count = repetitions();
        for(int i = 0; i < 13-FULL_SIZE; i++){
            if(count[i]*count[i+1]*count[i+2]*count[i+3]*count[i+4]==1){
                return true;
            }
        }
        if(count[0]*count[9]*count[10]*count[11]*count[12]==1){
            return true;
        }
        return false;
    }
    /**
     * Determines if hand is a pair.
     *
     * <p>This if 1 pair of ranks is present.</p>
     *
     * @return if the hand is a pair, true/false
     */
    public boolean isPair(){
        boolean flag=false;
        if(size()!=FULL_SIZE){
            return false;
        }
        int[] count = repetitions();
        for(int i = 0; i < 13; i++){
            if(count[i]==2){
                flag=!flag;
            }
        }
        if(isThreeOfAKind()){
            flag=false;
        }
        return flag;
    }
    /**
     * Discards hand to a specified deck (moves cards).
     *
     * @param deck the specified deck to move cards to
     */
    public void discardTo(Deck deck){
        if(isEmpty()){
            throw new CardException("error");
        }
        for(Card card: cards){
            deck.add(card);
        }
        cards.clear();
    }

    /**
     * Overrides original discard function, clears all cards in hand.
     */
    @Override
    public void discard() {
        if(isEmpty()){
            throw new CardException("error");
        }
        cards.clear();
    }
    /**
     * Adds a specific card to current poker hand.
     *
     * @param card the card object to add to the hand
     */
    @Override
    public void add(Card card){
        if(size()==FULL_SIZE){
            throw new CardException("error");
        }
        if(cards.contains(card)){
            throw new CardException("error");
        }
        cards.add(card);
    }
    /**
     * Returns the deck formatted as a string for printing.
     *
     * @return formatted string for printing
     */
    @Override
    public String toString(){
        List<String> cardList = new ArrayList<>();
        for(Card card: cards){
            cardList.add(card.toString());
        }
        return String.join(" ",cardList);
    }
}