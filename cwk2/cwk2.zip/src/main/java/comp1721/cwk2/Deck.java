package comp1721.cwk2;
import java.util.*;

/**
 * A class to represent a deck of 52 playing cards.
 *
 * <p>Should model an occurrence of a deck of cards
 * which can be shuffled. Cards can be removed and
 * added accordingly.</p>
 *
 * @author Saul Cooperman
 */

public class Deck extends CardCollection{
    /**
     * Constructor for Deck class.
     */
    public Deck(){
        for(Card.Suit suit: Card.Suit.values()){
            for(Card.Rank rank: Card.Rank.values()){
                add(new Card(rank,suit));
            }
        }
    }
    /**
     * Shuffles the cards in the deck.
     */
    public void shuffle() {
        Collections.shuffle(cards);
    }
    /**
     * Removes card from top of deck and returns it.
     *
     * @return the card it draws
     */
    public Card deal() {
        if(isEmpty()){
            throw new CardException("error");
        }
        Card card = cards.get(0);
        cards.remove(0);
        return card;
    }
}